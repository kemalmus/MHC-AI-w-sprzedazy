# Jak prowadzić warsztat BudMax

## Przygotowanie

Każdy uczestnik potrzebuje dostępu do zatwierdzonego narzędzia AI i własnego wątku rozmowy. Sprawdź wczytywanie materiałów, kopiowanie promptów i zapis notatek. Uczestnicy mogą pracować w małych grupach, ale każdy powinien obsługiwać AI, testować instrukcje i prowadzić symulację. Gdy grupa ma jedno urządzenie, zmieniaj operatora przy kolejnych zadaniach.

Główny cel: przeprowadzić jedną sprawę od maila do uzgodnionego następnego kroku, korzystając z AI przy tworzeniu materiałów, analizie źródeł i ćwiczeniu rozmów. Wynik każdego etapu jest wejściem do następnego.

## Rytm pracy

- Od pierwszego kroku używamy AI. Nie wymagamy ręcznego szkicu maila, planu ani propozycji przed otwarciem narzędzia.
- Uczestnik podaje źródła, cel i format, generuje wynik, sprawdza kluczową informację i zmienia jedną instrukcję. Następnie uruchamia prompt ponownie i porównuje rezultat.
- AI gra Annę lub CFO. Każdy prowadzi dialog tekstowo lub głosowo w dostępnym zatwierdzonym środowisku. Symulacja i coaching są częścią praktycznej pracy z narzędziem.
- Polecenie STOP kończy rolę klienta i uruchamia ocenę wypowiedzi. NOWA RUNDA uruchamia kolejną niezależną próbę na tych samych danych, a w module 6 ROLA CFO przełącza odbiorcę. Ocenę trzeba porównać z zapisem rozmowy; model nie powinien przypisywać handlowcowi pytań, których nie zadał.
- Po coachingu uczestnik testuje jedną zmianę w kolejnym dialogu. Zapisuje wyłącznie informacje ujawnione w rozmowie, nie całą wiedzę ze scenariusza klienta.
- Omówienia grupowe są krótkie i służą porównaniu skutecznych instrukcji. Nie zastępują indywidualnej pracy z AI.
- Uczestnik wkleja zweryfikowany wynik AI do notatek sprawy. Strona zapisuje je lokalnie i nie przesyła automatycznie do modelu. Każdy zachowuje własny przebieg rozmów w narzędziu.

## Co buduje się przez dzień

| Etap | Praktyczna praca z AI | Rezultat do kolejnego etapu |
| --- | --- | --- |
| 1 | Generowanie odpowiedzi i test dwóch wariantów | Odpowiedź i cel spotkania |
| 2 | Plan discovery i krótka symulacja otwarcia | Plan i pytania |
| 3 | AI jako Anna, coaching i ponowny dialog | Potrzeby i proces decyzji |
| 4 | Rekomendacja, krytyka i test zmiany priorytetu | Propozycja i blokady |
| 5 | Zapytania oraz analiza odpowiedzi zespołów | Potwierdzenia i otwarte warunki |
| 6 | Argumentacja i AI jako Anna oraz CFO | Argumenty i reakcje klienta |
| 7 | Negocjacje z AI jako CFO | Zakres porównania i następny krok |
| 8 | Analiza warunków i symulacja wyjaśnienia | Luka w zakresie i działanie |
| 9 | Plan, rozmowa finałowa i follow-up z AI | Mail oparty na dialogu |
| 10 | Audyt, minimalizacja danych i korekta w AI | Sprawdzony materiał |
| 11 | Plan testu i próbne uruchomienie promptu | Zastosowanie do sprawdzenia w pracy |

## Scenariusze i źródła

Scenariusze Anny, CFO i reguły finału są w promptach odpowiednich modułów. Plik `materials/budmax_client_cards.md` jest referencją dla trenera; jego części A, C i D muszą być zgodne z promptami. To materiał do odgrywania roli, nie lista ustaleń do automatycznego wpisania w notatkę. Uczestnik może znać scenariusz; oceniamy prowadzenie rozmowy i korzystanie z narzędzia, a nie odgadywanie tajnych odpowiedzi.

W module 5 udostępnij część B dopiero po wygenerowaniu zapytań. Jest to odpowiedź zespołów w scenariuszu, którą uczestnicy analizują z AI. W module 8 dołącz nowy fragment warunków. Nie zastępuj tych materiałów wygenerowanymi odpowiedziami działów.

Nie mieszaj źródeł wcześniejszego programu z aktualnym case’em. Główny przebieg korzysta z maila, historycznego CRM, ofert dealerów, katalogu, scenariuszy i fragmentu warunków. Moduł 12 jest osobnym opcjonalnym wariantem i nie aktualizuje notatek głównego case’u.

## Organizacja czasu i problemy z dostępem

Agenda i długości modułów wyznaczają ramy dnia; poszczególne kroki nie mają oznaczeń czasu. Skracaj omówienia na forum, zachowując generowanie, sprawdzenie i ponowny test. Gdy jedno narzędzie jest niedostępne, użyj innego zatwierdzonego środowiska lub wspólnego stanowiska z rotacją operatora. Nie zastępuj czasu ćwiczenia samodzielnym pisaniem dokumentów. Jeśli żadne narzędzie nie działa, przywróć dostęp i jawnie skoryguj agendę.

Sprawdzenie jednego cytatu, liczby lub zgody klienta w źródle jest częścią pracy z AI. Nie usuwaj tej kontroli w celu zwiększenia liczby wygenerowanych odpowiedzi. Przy problemie z zapisem strony użyj lokalnego dokumentu na wyniki AI z nagłówkami etapów 1–10.

## Ocena rezultatów

Uczestnik potrafi wskazać zmianę instrukcji lub kontekstu, która poprawiła wynik, zweryfikować twierdzenie modelu oraz przetestować poprawkę w rozmowie. W finale mail ma odzwierciedlać dialog, a zgoda na działanie powinna mieć podstawę w zapisie. Sama płynność wypowiedzi modelu nie jest miarą skuteczności.

Zaznaczenie ukończenia modułu jest samooceną. Po pilotażu sprawdź, czy każdy pracował z narzędziem, uruchamiał poprawione prompty i potrafił uzasadnić wybór końcowego wyniku.

## Jakość promptów

Aktualne zasady, podstawa w dokumentacji OpenAI oraz scenariusze do oceny odpowiedzi są w `docs/prompt-review-current.md`. Porównuj ten sam materiał i jedną zmianę instrukcji naraz. Sprawdzenie struktury promptu nie dowodzi poprawności odpowiedzi modelu.
