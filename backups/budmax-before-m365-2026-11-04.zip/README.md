# AI w sprzedaży

Jednodniowy warsztat na jednej szansie sprzedażowej BudMax. Cel: doprowadzić zapytanie o ratę do uzgodnionego następnego kroku. Program główny trwa 09:00–17:10; osobne opcjonalne dodatki kończą się o 18:40.

## Przebieg dnia

1. Odpowiedź na lead i otwarcie rozmowy.
2. Plan discovery na podstawie maila i historycznego CRM.
3. Rozmowa z Anną: potrzeba, wpływ na biznes, kryteria i decyzja.
4. Propozycja oparta na własnym discovery i ofertach dealerów.
5. Usunięcie blokad z dealerem, operacjami i Ryzykiem.
6. Argumentacja dla Anny i CFO.
7. Rozmowa o cenie i porównywalności oferty FleetPro.
8. Wyjaśnienie ograniczeń auta zastępczego.
9. Rozmowa finałowa i follow-up.
10. Kontrola własnego materiału przed wysłaniem.
11. Jeden konkretny test do wykonania w pracy.

Każdy etap określa wejście, rezultat i kryteria sukcesu. Uczestnicy pracują z AI od pierwszego kroku: generują wynik, sprawdzają go, zmieniają instrukcję i testują ponownie. AI gra Annę lub CFO w symulacjach; krótkie omówienia grupowe służą porównaniu skutecznych promptów. W głównym programie nie budujemy mikroaplikacji ani kampanii. Materiały tych wcześniejszych ćwiczeń pozostają w repozytorium jako archiwum.

## Uruchomienie lokalne

```sh
python3 -m http.server 8000
```

Otwórz `http://localhost:8000`. Strona pobiera JSON przez HTTP, więc nie otwieraj `index.html` jako `file://`. Nie wymaga buildu, backendu ani kluczy API. Uczestnicy sami kopiują wybrane dane i prompty do zatwierdzonego narzędzia.

## Prowadzenie

Przed warsztatem przeczytaj [instrukcję trenera](docs/trainer-flow.md) i [scenariusze rozmów](materials/budmax_client_cards.md). Scenariusze roli Anny, CFO i finału są w promptach modułów 3, 7 i 9. Część B udostępnij w module 5 po wygenerowaniu zapytań. Każdy uczestnik powinien mieć możliwość bezpośredniej pracy z narzędziem.

Tryb trenera pokazuje wskazówki, timer i odnośnik do scenariuszy. Po odświeżeniu jest wyłączony. Hasło ukrywa elementy interfejsu, ale pliki strony są publiczne. Fast mode skraca omówienie na forum; zachowuje pracę z AI, sprawdzenie źródła i ponowny test każdej osoby.

## Notatki sprawy i zapis

W modułach 1–10 uczestnik wkleja wynik pracy z AI w polu notatek sprawy. Następne moduły pokazują wcześniejsze wpisy w rozwijanej sekcji „Dotychczasowe ustalenia”. Brak wpisu pozostaje widocznym brakiem; strona nie uzupełnia go przykładową odpowiedzią. Zapisuj faktycznie uzyskane ustalenia, ich źródła i otwarte pytania.

Notatki sprawy, postęp i plan wdrożenia zapisują się w `localStorage` tej przeglądarki. Nie synchronizują się między urządzeniami i nie trafiają na serwer. Można wyeksportować notatki sprawy i plany zastosowania AI do Markdown. Reset usuwa zapisy obecnej wersji warsztatu.

Nowy program używa klucza `mhc-ai-sales-training-v2`. Zapisy poprzedniego programu pod kluczem `v1` pozostają w przeglądarce, ale nie są wyświetlane jako postęp nowego case’u.

## Edycja i weryfikacja

- Treści, agenda, kryteria, prompty i notatki trenera: `source/training_content.json`.
- Interfejs i zapis notatek sprawy: `assets/js/app.js`, `assets/css/site.css`, `index.html`.
- Scenariusze rozmów: `materials/budmax_client_cards.md`.
- Nowy fragment warunków: `materials/budmax_service_excerpt.txt`. W głównym programie nie zastępuj go wcześniejszą umową z innych ćwiczeń.
- Instrukcje edycji: [EDYCJA.md](EDYCJA.md).
- Aktualne zasady promptów i scenariusze ewaluacji: [docs/prompt-review-current.md](docs/prompt-review-current.md). `docs/prompt-review.md` dokumentuje poprzednią wersję.

Weryfikacja składni:

```sh
python3 -m json.tool source/training_content.json > /dev/null
node --check assets/js/app.js
```

Sprawdź też na stronie zapis wyniku, jego widoczność w następnym module, zachowanie po odświeżeniu, eksport i odsłanianie kroków. Kroki nie mają oznaczeń czasu; agenda dnia i długości modułów pozostają widoczne. Sprawdź ciągłość agendy i kompletność promptów.

## Publikacja

Zmiany w `main` uruchamiają GitHub Actions: kontrolę składni i publikację GitHub Pages. Linki są względne, więc działają także w podkatalogu repozytorium.

BudMax jest scenariuszem szkoleniowym. Nie dopisuj rzeczywistych warunków MHC ani danych klientów. Moduł 12 to odrębny wariant przetargowy: nowy wątek i osobne notatki, bez aktualizowania notatek głównego case’u. Moduł 13 pozostaje opcjonalnym przeglądem narzędzi.
